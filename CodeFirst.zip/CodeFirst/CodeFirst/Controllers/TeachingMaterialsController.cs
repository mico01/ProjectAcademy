﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CodeFirst.DB;
using CodeFirst.Models;

namespace CodeFirst.Controllers
{
    public class TeachingMaterialsController : Controller
    {
        private readonly MyDB _context;

        public TeachingMaterialsController(MyDB context)
        {
            _context = context;
        }

        // GET: TeachingMaterials
        public async Task<IActionResult> Index()
        {
            return View(await _context.TeachingMaterial.ToListAsync());
        }

        // GET: TeachingMaterials/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var teachingMaterial = await _context.TeachingMaterial
                .FirstOrDefaultAsync(m => m.Id == id);
            if (teachingMaterial == null)
            {
                return NotFound();
            }

            return View(teachingMaterial);
        }

        // GET: TeachingMaterials/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: TeachingMaterials/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Lesson,MaterialLink,Name,ShortDescription,Description,IsCommonBlock,Id")] TeachingMaterial teachingMaterial)
        {
            if (ModelState.IsValid)
            {
                teachingMaterial.Id = Guid.NewGuid();
                _context.Add(teachingMaterial);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(teachingMaterial);
        }

        // GET: TeachingMaterials/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var teachingMaterial = await _context.TeachingMaterial.FindAsync(id);
            if (teachingMaterial == null)
            {
                return NotFound();
            }
            return View(teachingMaterial);
        }

        // POST: TeachingMaterials/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind("Lesson,MaterialLink,Name,ShortDescription,Description,IsCommonBlock,Id")] TeachingMaterial teachingMaterial)
        {
            if (id != teachingMaterial.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(teachingMaterial);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TeachingMaterialExists(teachingMaterial.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(teachingMaterial);
        }

        // GET: TeachingMaterials/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var teachingMaterial = await _context.TeachingMaterial
                .FirstOrDefaultAsync(m => m.Id == id);
            if (teachingMaterial == null)
            {
                return NotFound();
            }

            return View(teachingMaterial);
        }

        // POST: TeachingMaterials/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            var teachingMaterial = await _context.TeachingMaterial.FindAsync(id);
            _context.TeachingMaterial.Remove(teachingMaterial);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TeachingMaterialExists(Guid id)
        {
            return _context.TeachingMaterial.Any(e => e.Id == id);
        }
    }
}
