﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models
{
    public class Exercise : Resource
    {
        public string AvalableTime { get; set; }

        public enum Status
        {
            Pending,
            Delivered,
            Returned,
            Checked
        }
    }
}
