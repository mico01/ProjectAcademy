﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models
{
    public class Resource : Entity
    {
        public string Name { get; set; }

        public string ShortDescription { get; set; }

        public string Description { get; set; }

        public enum Itinerary
        {
            FrontEnd,
            BackEnd,
            Java,
            Net,
        };

        public bool IsCommonBlock { get; set; }
    }

}
