﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models.Enums
{
    public enum MaterialTypes
    { 
            video,
            document,
            other
       
    }
}
