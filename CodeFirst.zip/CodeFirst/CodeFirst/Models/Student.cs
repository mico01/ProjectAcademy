﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models
{
    public class Student : Person
    {
        public int Absences { get; set; }

        public DateTime LastLogin { get; set; }

        public DateTime BeginData { get; set; }

        public DateTime EndData { get; set; }

        public enum Itinerary
        {
            FrontEnd,
            BackEnd,
            Java,
            Net,
        };

    }
}
