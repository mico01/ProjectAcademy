﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.Models
{
    public class Person : Entity
    {
        public string Name { get; set; }

        public string LastName { get; set; }

        public string CompleteName
        {
            get
            {
                return this.Name + " " + this.LastName;
            }
        }

        public int Age { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public enum Gender
        {
            Male,
            Female,
            Other,
            Undefined
        }

        public string Picture { get; set; }

    }
}
