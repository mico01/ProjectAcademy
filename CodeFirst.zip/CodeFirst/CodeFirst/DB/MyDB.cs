﻿using CodeFirst.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CodeFirst.DB
{
    public class MyDB : DbContext
    {
        public MyDB (DbContextOptions<MyDB> options ): base(options)
        {

        }

        public DbSet<Student> Student { get; set; }
        public DbSet<Event> Event { get; set; }
        public DbSet<Exercise> Exercise { get; set; }
        public DbSet<TeachingMaterial> TeachingMaterial { get; set; }

    }
}
